package nagiosWeb;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DbZugriff 
{
	
	Statement stmt;
	String host	="10.20.40.30";
	String database = "nagios_jambo";
	String user = "root";
	String passwd = "nagios";
	
	
	public Connection connectToMysql()
	{
		Connection connection;
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
				String connectionCommand = "jdbc:mysql://"+host+"/"+database+"?user="+user+"&password="+passwd;
				System.out.println(connectionCommand);
				
				connection = DriverManager.getConnection(connectionCommand);
				return connection;
			}
			catch (Exception ex)
			{
				System.out.println("ERROR bei connection");
				System.out.println(ex);
				return null;
			}
	}
	
	public ResultSet execute(String sCommand)
	{
		ResultSet rs = null;
		Statement stmt = null;
		Connection connection = this.connectToMysql();
		
		
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sCommand);
			if (stmt.execute(sCommand)) {
		        rs = stmt.getResultSet();
		    }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return rs;
	}
	
	public boolean userExist(String sUser) throws SQLException
	{
		ResultSet rs = this.execute("select count(*) from user where Benutzerkonto = '"+sUser+"'");
		rs.beforeFirst();
		rs.next();
		if(rs.getInt(1)>=1)
		{
			System.out.println("TUREEEEE");
			
			
			return true;
		}
		else
		{
			System.out.println("FALSSSEEE");
			return false;
		}
	}
	
	public boolean loginAut(String sUser, String sPassword) throws SQLException
	{
		if(this.userExist(sUser))
		{
			String pwHash = Hash.get_SHA_512_SecurePassword(sPassword);
			
			ResultSet rs = this.execute("select count(*) from user where Password = '"+pwHash+"'");
			rs.beforeFirst();
			rs.next();
			if(rs.getInt(1)>=1)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	
	
	
	
		

}
