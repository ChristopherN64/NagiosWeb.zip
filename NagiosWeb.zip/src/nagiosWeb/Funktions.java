package nagiosWeb;

import java.security.*;


public class Funktions  {

	
	
	
	

}
