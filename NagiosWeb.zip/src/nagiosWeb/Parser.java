package nagiosWeb;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class Parser {
	private String jsonPath;
	private String scriptPath;
	
	public Parser(String jsonPath, String scriptPath) {
		this.setJsonPath(jsonPath);
		this.setScriptPath(scriptPath);
	}
	
	public String getJsonPath() {
		return this.jsonPath;
	}
	
	public void setJsonPath(String jsonPath) {
		this.jsonPath = jsonPath;
	}
	
	public String getScriptPath() {
		return this.scriptPath;
	}
	
	public void setScriptPath(String scriptPath) {
		this.scriptPath = scriptPath;
	}
	
	/*
	 * Führt das Skript zum runterladen der JSON Datei aus
	 * Die ID und dir Uhrzeit werden im Dateinamen gespeichert
	 * Zurückgegeben wird der Dateiname
	 */
	public String executeScript(String id) {
		String dateiname = new String();
		// Datum
		Date date = new Date();
		SimpleDateFormat df = new SimpleDateFormat("YMd_H_m_s");
		
		dateiname += df.format(date);
		dateiname += "_" + id;
		
		ProcessBuilder pb = new  ProcessBuilder(this.getScriptPath(), dateiname);
		pb.inheritIO();
		
		try {
			Process process = pb.start();
			int processExit = process.waitFor();
			
			while(processExit != 0) {
				new BufferedInputStream(process.getErrorStream());
				throw new RuntimeException("execution of script failed");
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		catch(InterruptedException e) {
			e.printStackTrace();
		}
		
		// Dateiendung andhängen
		dateiname += ".json";
		
		return dateiname;
	}
	
	public void executeScriptRemove(String dateiname) {
		ProcessBuilder pb = new  ProcessBuilder("rm", this.getJsonPath() + dateiname);
		pb.inheritIO();
		
		try {
			Process process = pb.start();
			int processExit = process.waitFor();
			
			while(processExit != 0) {
				new BufferedInputStream(process.getErrorStream());
				throw new RuntimeException("execution of script failed");
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * Liefert alle Hostnamen
	 */
	public ArrayList<String> getHosts(String dateiname) {
		JSONParser parser = new JSONParser();
		ArrayList<String> hostname = new ArrayList<String>();
		
		try {
			// Read file
			Object obj = parser.parse(new FileReader(this.getJsonPath() + dateiname));
			
			JSONObject jobj = (JSONObject) obj;
			
			JSONArray main = (JSONArray)jobj.get("hosts");
			
			// Get Hosts
			for(Object o : main) {
				JSONObject host = (JSONObject) o;
				hostname.add((String) host.get("host_name"));
			}
			
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		catch(ParseException e) {
			e.printStackTrace();
		}
		
		return hostname;
	}
	
	/*
	 * gibt die ServiceList eines host zurück
	 */
	public ArrayList<ArrayList<String>> getServices(String dateiname, String host) {
		JSONParser parser = new JSONParser();
		
		ArrayList<ArrayList<String>> outer = new ArrayList<ArrayList<String>>();
		ArrayList<String> inner = new ArrayList<String>();
		
		try {
			Object obj = parser.parse(new FileReader(this.getJsonPath() + dateiname));
			
			JSONObject jobj = (JSONObject) obj;
			
			JSONArray main = (JSONArray)jobj.get("services");
			
			// Get Services
			for(Object o : main) {
				JSONObject service = (JSONObject) o;
				
				if(((String) service.get("host_name")).equals(host)) {
					
					inner.add((String) service.get("service_description"));
					inner.add((String) service.get("plugin_output"));
					
					outer.add(inner);
					inner = new ArrayList<String>();
				}
				
				
			}
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		catch(ParseException e) {
			e.printStackTrace();
		}
		
		return outer;
	}
	
	/*
	public static void main(String args[]) {
		
		Parser p = new Parser("/home/lfleper/Dokumente/test/", "/home/lfleper/Dokumente/test/NagiosJSON.sh");
		

		String dateiname = p.executeScript("1");
		System.out.println(dateiname);
		

		ArrayList<String> hosts = p.getHosts(dateiname);
		
		for(String s : hosts) {
			System.out.println(s);
		}
		
		System.out.println("----------------");
		

		ArrayList<ArrayList<String>> services = p.getServices(dateiname, "lukas");
		
		for(int i = 0; i < services.size(); i++) {
			for(int l = 0; l < services.get(i).size(); l++) {
				System.out.println(services.get(i).get(l));
			}
			System.out.println();
		}
		
		p.executeScriptRemove(dateiname);
	}
	*/
}